# OTV-YTS
Gemilere verilen Özel Tüketim Vergisi İndirilmiş Yakıtların Usulüne uygun kullanılıp kullanılmadığını denetleyen bir web yazılımı.
